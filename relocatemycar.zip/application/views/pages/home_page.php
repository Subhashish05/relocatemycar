<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Home</title>
	<link rel="stylesheet" href="<?php echo base_url('css/bootstrap.min.css')  ?>">
	<link rel="stylesheet" href="<?php echo base_url('css/bootstrap-grid.min.css')  ?>">
	<link rel="stylesheet" href="<?php echo base_url('css/bootstrap-utilities.min.css')  ?>">
	<link rel="stylesheet" href="<?php echo base_url('css/style.css')  ?>">
	<link rel="stylesheet" href="<?php echo base_url('css/home.css')  ?>">
</head>

<body>
	<header>
		<?php include 'nav.php'; ?>
		<section class="hero_section px-0 px-lg-5 py-4">
			<div class="col-12 col-lg-8">
				<span class="theme_bg fw-bold rounded-pill px-3 py-1">IBA Approved Packers and Movers</span>
				<h1 class="text-white">Car Shifting Services in India</h1>
			</div>
			<div class="col-12 col-lg-4">
				<form action="" class="header_form px-3 py-2">
					<div class="text-center">
						<h3 class="theme_text theme_underline">Connect With Us</h3>
					</div>
					<div class="my-2">
						<label for="name">Name</label>
						<input type="text" name="name" id="name" class="form-control">
					</div>
					<div class="mb-2">
						<label for="email">E-mail</label>
						<input type="text" name="email" id="email" class="form-control">
					</div>
					<div class="mb-2">
						<label for="mobile">Mobile</label>
						<input type="text" name="mobile" id="mobile" class="form-control">
					</div>
					<div class="mb-2">
						<label for="desc">Description</label>
						<textarea name="desc" id="desc" class="form-control"></textarea>
					</div>
					<div class="mb-2 text-center">
						<button type="submit" class="theme_btn rounded-pill w-100">Submit</button>
					</div>
				</form>
			</div>
		</section>
	</header>
	<main>
		<section class="d-flex flex-wrap py-4 px-0 px-lg-5">
			<div class="imp_points col-6 col-md-4 col-lg-2 mb-4">
				<div class="imp_point_heading">
					<img src="<?php echo base_url('image/calender.png')?>" alt="icon">
					<strong>300+</strong>
				</div>
				<p class="imp_point_desc">
					Cities Covered
				</p>
			</div>
			<div class="imp_points col-6 col-md-4 col-lg-2 mb-4">
				<div class="imp_point_heading">
					<img src="<?php echo base_url('image/premium.png')?>" alt="icon">
					<strong>25+</strong>
				</div>
				<p class="imp_point_desc">
					Branches
				</p>
			</div>
			<div class="imp_points col-6 col-md-4 col-lg-2 mb-4">
				<div class="imp_point_heading">
					<img src="<?php echo base_url('image/customer.png')?>" alt="icon">
					<strong>370000+</strong>
				</div>
				<p class="imp_point_desc">
					Happy Customers
				</p>
			</div>
			<div class="imp_points col-6 col-md-4 col-lg-2 mb-4">
				<div class="imp_point_heading">
					<img src="<?php echo base_url('image/solution.png')?>" alt="icon">
					<strong>36+</strong>
				</div>
				<p class="imp_point_desc">
					Years of <br>
					Exemplary Service
				</p>
			</div>
			<div class="imp_points col-6 col-md-4 col-lg-2 mb-4">
				<div class="imp_point_heading">
					<img src="<?php echo base_url('image/Star.png')?>" alt="icon">
					<strong>1000+</strong>
				</div>
				<p class="imp_point_desc">
					Stellar <br>
					5-Star Ratings
				</p>
			</div>
			<div class="imp_points col-6 col-md-4 col-lg-2 mb-4">
				<div class="imp_point_heading">
					<img src="<?php echo base_url('image/refral.png')?>" alt="icon">
					<strong>98%</strong>
				</div>
				<p class="imp_point_desc">
					Customer <br>
					Referral Rating
				</p>
			</div>
		</section>
		<article class="py-4 px-0 px-lg-5 experience">
			<h2 class="theme_text theme_underline text-center col-12 mb-5">Choose Anil Packers and Movers for a Reliable Car Transport Experience</h2>
			<div class="col-lg-6 col-12 exp_card">
				<img src="<?php echo base_url('image/image.png') ?>" alt="logo">
				<div class="exp_desc">
					<h5 class="theme_text my-2">Authentic and Certified</h5>
					<p class="text_justify px-4">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed a fugit numquam et consequatur veritatis beatae impedit, incidunt quibusdam corrupti voluptate tempora unde suscipit odit autem amet deserunt iste vitae neque quia, perspiciatis illum, ex nisi voluptatum. Enim ad, dolor voluptatum minima quibusdam voluptatibus veritatis ipsum aperiam ullam dolores neque?</p>
				</div>
			</div>
			<div class="col-lg-6 col-12 exp_card">
				<img src="<?php echo base_url('image/image.png') ?>" alt="logo">
				<div class="exp_desc">
					<h5 class="theme_text my-2">Experienced</h5>
					<p class="text_justify px-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae quidem nesciunt placeat eveniet rem dolores in quod nihil nostrum, alias sint reprehenderit accusamus assumenda sequi dolore laudantium molestias vel quasi! Delectus unde, laudantium iusto velit dolore vel blanditiis voluptatem maiores. Labore rem accusantium cumque exercitationem, officiis corrupti totam repellat suscipit.</p>
				</div>
			</div>
			<div class="col-lg-6 col-12 exp_card">
				<img src="<?php echo base_url('image/image.png') ?>" alt="logo">
				<div class="exp_desc">
					<h5 class="theme_text my-2">Flexible</h5>
					<p class="text_justify px-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veniam provident vel aut. Dolorem corporis ipsam itaque nobis asperiores quod velit alias officiis, in iusto ratione dolor unde? Mollitia in dolorem corporis aliquam. Sapiente voluptas saepe quos animi accusamus consequuntur magni optio iste provident est, voluptates iusto nemo facere harum! Cumque.</p>
				</div>
			</div>
			<div class="col-lg-6 col-12 exp_card">
				<img src="<?php echo base_url('image/image.png') ?>" alt="logo">
				<div class="exp_desc">
					<h5 class="theme_text my-2">Affordable</h5>
					<p class="text_justify px-4">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Iusto ex mollitia eius voluptatem at tempora enim dolorum reprehenderit provident facilis voluptate molestiae nulla minima illum saepe quidem, vitae vel explicabo perspiciatis. Ipsa, quia ducimus. Asperiores, molestiae maiores voluptatem sed, ipsam unde consectetur, iure at eligendi in deserunt! At, deleniti neque!</p>
				</div>
			</div>
			<div class="col-lg-6 col-12 exp_card">
				<img src="<?php echo base_url('image/image.png') ?>" alt="logo">
				<div class="exp_desc">
					<h5 class="theme_text my-2">On-Time</h5>
					<p class="text_justify px-4">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eum ipsum voluptates facere suscipit! Tempora, id debitis nihil ad non laboriosam culpa obcaecati nisi labore velit alias quas aliquam laudantium expedita ex aliquid cum et voluptas voluptatum, quaerat voluptates ab. Accusantium quibusdam enim beatae id natus, non blanditiis cupiditate dolore eligendi!</p>
				</div>
			</div>
			<div class="col-lg-6 col-12 exp_card">
				<img src="<?php echo base_url('image/image.png') ?>" alt="logo">
				<div class="exp_desc">
					<h5 class="theme_text my-2">Constant Support</h5>
					<p class="text_justify px-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Porro facilis corporis eos eveniet officiis? Aliquid consectetur iure dolorem expedita! Fuga repudiandae esse consectetur consequuntur quaerat obcaecati impedit accusantium eius odio velit, enim omnis commodi fugiat nostrum quia doloremque sint error, ab inventore quibusdam odit. Architecto ullam incidunt molestias excepturi doloremque?</p>
				</div>
			</div>
		</article>
		<article class="py-4 px-0 px-lg-5 professional">
			<h2 class="theme_text theme_underline text-center col-12 mb-5">Professional Vehicle Transport Services with Anil Packers and Movers</h2>
			<div class="pro_card">
				<img src="<?php echo base_url('image/image.png') ?>" alt="logo">
				<div class="text-center">
					<h5 class="theme_text my-2">Local Car Carrier Services</h5>
					<p class="text_justify px-4">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed a fugit numquam et consequatur veritatis beatae impedit, incidunt quibusdam corrupti voluptate tempora unde suscipit odit autem amet deserunt iste vitae neque quia, perspiciatis illum, ex nisi voluptatum. Enim ad, dolor voluptatum minima quibusdam voluptatibus veritatis ipsum aperiam ullam dolores neque?</p>
				</div>
			</div>
			<div class="pro_card">
				<img src="<?php echo base_url('image/image.png') ?>" alt="logo">
				<div class="text-center">
					<h5 class="theme_text my-2">Domestic Vehicle Shifting Services</h5>
					<p class="text_justify px-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae quidem nesciunt placeat eveniet rem dolores in quod nihil nostrum, alias sint reprehenderit accusamus assumenda sequi dolore laudantium molestias vel quasi! Delectus unde, laudantium iusto velit dolore vel blanditiis voluptatem maiores. Labore rem accusantium cumque exercitationem, officiis corrupti totam repellat suscipit.</p>
				</div>
			</div>
			<div class="pro_card">
				<img src="<?php echo base_url('image/image.png') ?>" alt="logo">
				<div class="text-center">
					<h5 class="theme_text my-2">Car Shifting Services by Train</h5>
					<p class="text_justify px-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veniam provident vel aut. Dolorem corporis ipsam itaque nobis asperiores quod velit alias officiis, in iusto ratione dolor unde? Mollitia in dolorem corporis aliquam. Sapiente voluptas saepe quos animi accusamus consequuntur magni optio iste provident est, voluptates iusto nemo facere harum! Cumque.</p>
				</div>
			</div>
		</article>
		<article class="py-4 px-0 px-lg-5 comphrehensive">
			<h2 class="theme_text theme_underline text-center col-12 mb-5">Choose Anil Packers and Movers for Comprehensive Car Shifting Services in India</h2>
			<div class="comphre_card">
				<div class="comphre_img">
					<img src="<?php echo base_url('image/image.png') ?>" alt="logo">
				</div>
				<div class="comphre_desc">
					<h5>Expert Car Moving Services</h5>
					<i>Years of expertise</i>
					<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Saepe velit laboriosam numquam est voluptatibus, error ex reprehenderit, excepturi maiores fuga eligendi corporis modi consequatur ratione commodi ipsum deserunt illum veritatis assumenda? Perferendis nesciunt ipsum ex maxime repellendus error qui, ut magnam totam et minima eligendi itaque debitis maiores? Id, porro.</p>
				</div>
			</div>
			<div class="comphre_card">
				<div class="comphre_img">
					<img src="<?php echo base_url('image/image.png') ?>" alt="logo">
				</div>
				<div class="comphre_desc">
					<h5>Personalized Car Moving Services</h5>
					<i>Special containers depending on the requirements</i>
					<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Libero praesentium, consequatur dolorum, quibusdam ea rem, iste architecto asperiores provident rerum vel. Amet necessitatibus maxime, voluptas quam rem quasi veniam explicabo voluptatibus quis atque ab natus corporis blanditiis beatae eos eaque, rerum ad soluta suscipit ullam aperiam harum nulla animi inventore.</p>
				</div>
			</div>
			<div class="comphre_card">
				<div class="comphre_img">
					<img src="<?php echo base_url('image/image.png') ?>" alt="logo">
				</div>
				<div class="comphre_desc">
					<h5>Continuous Support</h5>
					<i>Dedicated team</i>
					<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Placeat esse, similique labore perspiciatis, reprehenderit iure consequatur, nihil neque illo consectetur perferendis autem accusamus deserunt a? Voluptate, totam praesentium perspiciatis tempora sit sunt, porro provident nostrum tenetur modi maxime consequuntur quaerat ipsam eum nobis molestias. Repellendus, at. Soluta maiores quibusdam necessitatibus.</p>
				</div>
			</div>
			<div class="comphre_card">
				<div class="comphre_img">
					<img src="<?php echo base_url('image/image.png') ?>" alt="logo">
				</div>
				<div class="comphre_desc">
					<h5>Insured Car Moving Services</h5>
					<i>Insurance options</i>
					<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Necessitatibus, eos molestiae blanditiis hic reprehenderit tempore vero ullam qui explicabo, commodi impedit quae? Nobis consequuntur dolor consequatur distinctio repellendus laboriosam aut magnam, quis rem fuga architecto, maiores amet, quo aliquid voluptatem quibusdam ipsa dolore est similique. Excepturi soluta eveniet eligendi animi.</p>
				</div>
			</div>
			<div class="comphre_card">
				<div class="comphre_img">
					<img src="<?php echo base_url('image/image.png') ?>" alt="logo">
				</div>
				<div class="comphre_desc">
					<h5>Flexible Car Moving Services</h5>
					<i>Flexible with any car types</i>
					<p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eveniet deserunt quam perferendis quo dignissimos exercitationem expedita temporibus vel debitis. Quisquam, eligendi aliquam vero ut error, veritatis beatae fugiat quod architecto quia et, enim a! Quae est hic, ipsum esse, doloribus necessitatibus, adipisci assumenda ratione labore earum dolorem unde omnis debitis!</p>
				</div>
			</div>
			<div class="comphre_card">
				<div class="comphre_img">
					<img src="<?php echo base_url('image/image.png') ?>" alt="logo">
				</div>
				<div class="comphre_desc">
					<h5>Widespread Car Moving Services</h5>
					<i>Transport Nationwide</i>
					<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam labore ad eaque nam, aspernatur tenetur! Iure maxime, sit mollitia iste, laborum asperiores placeat optio veritatis ex aut libero sequi ipsam exercitationem natus iusto nam quasi fuga. Omnis nostrum magni, maxime nulla tempora autem neque distinctio cumque ut doloribus expedita blanditiis!</p>
				</div>
			</div>
			<div class="comphre_card">
				<div class="comphre_img">
					<img src="<?php echo base_url('image/image.png') ?>" alt="logo">
				</div>
				<div class="comphre_desc">
					<h5>Evergreen Car Moving Services</h5>
					<i>Available throughout the year</i>
					<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Id, obcaecati voluptatibus. Amet, optio. Beatae sunt omnis aut cum quod illo perspiciatis minima. Hic suscipit, fuga quidem maiores incidunt asperiores laboriosam eius quasi et necessitatibus minima? Necessitatibus doloribus voluptas delectus harum aliquam consequatur quod dolorum, dolorem ea eaque vel ut deserunt!</p>
				</div>
			</div>
		</article>
		<article class="py-4 px-0 px-md-3 px-lg-5 process">
			<h2 class="theme_text theme_underline text-center col-12 mb-5">Process to Book Car Transportation Services in India with Anil Packers and Movers</h2>
			<div class="process_card">
				<img src="<?php echo base_url('image/image.png') ?>" alt="logo">
				<h5 class="theme_text fw-bold mb-0">1. Share Details</h5>
				<p>Anil Packers and Movers is government-registered</p>
			</div>
			<div class="arrow"></div>
			<div class="process_card">
				<img src="<?php echo base_url('image/image.png') ?>" alt="logo">
				<h5 class="theme_text fw-bold mb-0">2.	Get Free Quote</h5>
				<p>We take care of every relocation aspect whether</p>
			</div>
			<div class="arrow"></div>
			<div class="process_card">
				<img src="<?php echo base_url('image/image.png') ?>" alt="logo">
				<h5 class="theme_text fw-bold mb-0">3.	Confirm Dates</h5>
				<p>Customer satisfaction is our top priority</p>
			</div>
		</article>
		<section class="py-4 px-0 px-md-3 px-lg-5 feedback" style="height: 300px;">
			<h2 class="theme_text theme_underline text-center col-12 mb-5">Customer Feedback</h2>
		</section>
		<section class="py-4 px-0 px-md-3 px-lg-5 topmost">
			<h2 class="theme_text theme_underline text-center col-12 mb-5">Choose Anil Packers and Movers for Topmost Car Transport in India</h2>
			<div class="topmost_btn_container">
				<button type="button" class="theme_btn rounded-pill">Get a Free Quote</button>
				<button type="button" class="theme_btn rounded-pill">WhatsApp</button>
			</div>
		</section>
		<section class="py-4 px-0 px-md-3 px-lg-5 faq">
			<h2 class="theme_text theme_underline text-center col-12 mb-5">Frequently Asked Questions</h2>
			<div class="faq_card">
				<div class="faq_q" onclick="openFaq(this)">
				1. What are Anil Packers and Movers’ car transportation charges?
				<div class="arrowdown"></div>
				</div>
				<div class="faq_a">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt deserunt laborum eos harum a nobis laudantium saepe temporibus recusandae explicabo. Iste quis omnis quasi, deserunt cum in maiores assumenda recusandae quos minus illum consequuntur quidem incidunt exercitationem nam adipisci ex ipsam? Et, debitis inventore nesciunt quas sint veritatis deserunt earum.</div>
			</div>
			<div class="faq_card">
				<div class="faq_q" onclick="openFaq(this)">
				2. What if my vehicle will be damaged while performing car shifting services?
				<div class="arrowdown"></div>
				</div>
				<div class="faq_a">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt deserunt laborum eos harum a nobis laudantium saepe temporibus recusandae explicabo. Iste quis omnis quasi, deserunt cum in maiores assumenda recusandae quos minus illum consequuntur quidem incidunt exercitationem nam adipisci ex ipsam? Et, debitis inventore nesciunt quas sint veritatis deserunt earum.</div>
			</div>
			<div class="faq_card">
				<div class="faq_q" onclick="openFaq(this)">
				3. What car carrier is utilized for car transportation services?
				<div class="arrowdown"></div>
				</div>
				<div class="faq_a">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt deserunt laborum eos harum a nobis laudantium saepe temporibus recusandae explicabo. Iste quis omnis quasi, deserunt cum in maiores assumenda recusandae quos minus illum consequuntur quidem incidunt exercitationem nam adipisci ex ipsam? Et, debitis inventore nesciunt quas sint veritatis deserunt earum.</div>
			</div>
			<div class="faq_card">
				<div class="faq_q" onclick="openFaq(this)">
				4. How Anil Packers and Movers makes it easy to hire the best car transportation services in India?
				<div class="arrowdown"></div>
				</div>
				<div class="faq_a">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt deserunt laborum eos harum a nobis laudantium saepe temporibus recusandae explicabo. Iste quis omnis quasi, deserunt cum in maiores assumenda recusandae quos minus illum consequuntur quidem incidunt exercitationem nam adipisci ex ipsam? Et, debitis inventore nesciunt quas sint veritatis deserunt earum.</div>
			</div>
			<div class="faq_card">
				<div class="faq_q" onclick="openFaq(this)">
				5. What are the steps to follow for initiating car shifting services with Anil Packers and Movers?
				<div class="arrowdown"></div>
				</div>
				<div class="faq_a">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt deserunt laborum eos harum a nobis laudantium saepe temporibus recusandae explicabo. Iste quis omnis quasi, deserunt cum in maiores assumenda recusandae quos minus illum consequuntur quidem incidunt exercitationem nam adipisci ex ipsam? Et, debitis inventore nesciunt quas sint veritatis deserunt earum.</div>
			</div>
			<div class="faq_card">
				<div class="faq_q" onclick="openFaq(this)">
				6. How long does vehicle transportation take in India? 
				<div class="arrowdown"></div>
				</div>
				<div class="faq_a">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt deserunt laborum eos harum a nobis laudantium saepe temporibus recusandae explicabo. Iste quis omnis quasi, deserunt cum in maiores assumenda recusandae quos minus illum consequuntur quidem incidunt exercitationem nam adipisci ex ipsam? Et, debitis inventore nesciunt quas sint veritatis deserunt earum.</div>
			</div>
			<div class="faq_card">
				<div class="faq_q" onclick="openFaq(this)">
				7.  Is NOC required for car transportation services to another Indian city/state?
				<div class="arrowdown"></div>
				</div>
				<div class="faq_a">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt deserunt laborum eos harum a nobis laudantium saepe temporibus recusandae explicabo. Iste quis omnis quasi, deserunt cum in maiores assumenda recusandae quos minus illum consequuntur quidem incidunt exercitationem nam adipisci ex ipsam? Et, debitis inventore nesciunt quas sint veritatis deserunt earum.</div>
			</div>
			<div class="faq_card">
				<div class="faq_q" onclick="openFaq(this)">
				8.  How do car movers or transporters package a car for vehicle transportation in India?
				<div class="arrowdown"></div>
				</div>
				<div class="faq_a">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt deserunt laborum eos harum a nobis laudantium saepe temporibus recusandae explicabo. Iste quis omnis quasi, deserunt cum in maiores assumenda recusandae quos minus illum consequuntur quidem incidunt exercitationem nam adipisci ex ipsam? Et, debitis inventore nesciunt quas sint veritatis deserunt earum.</div>
			</div>
			<div class="faq_card">
				<div class="faq_q" onclick="openFaq(this)">
				9. What is the process of hiring Car transport service through Anil Packers and Movers?
				<div class="arrowdown"></div>
				</div>
				<div class="faq_a">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt deserunt laborum eos harum a nobis laudantium saepe temporibus recusandae explicabo. Iste quis omnis quasi, deserunt cum in maiores assumenda recusandae quos minus illum consequuntur quidem incidunt exercitationem nam adipisci ex ipsam? Et, debitis inventore nesciunt quas sint veritatis deserunt earum.</div>
			</div>
			<div class="faq_card">
				<div class="faq_q" onclick="openFaq(this)">
				10. Is my car safe with your car moving service?
				<div class="arrowdown"></div>
				</div>
				<div class="faq_a">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt deserunt laborum eos harum a nobis laudantium saepe temporibus recusandae explicabo. Iste quis omnis quasi, deserunt cum in maiores assumenda recusandae quos minus illum consequuntur quidem incidunt exercitationem nam adipisci ex ipsam? Et, debitis inventore nesciunt quas sint veritatis deserunt earum.</div>
			</div>
			<div class="faq_card">
				<div class="faq_q" onclick="openFaq(this)">
				11. What are the components of movings costs of car transport services?
				<div class="arrowdown"></div>
				</div>
				<div class="faq_a">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt deserunt laborum eos harum a nobis laudantium saepe temporibus recusandae explicabo. Iste quis omnis quasi, deserunt cum in maiores assumenda recusandae quos minus illum consequuntur quidem incidunt exercitationem nam adipisci ex ipsam? Et, debitis inventore nesciunt quas sint veritatis deserunt earum.</div>
			</div>
			<div class="faq_card">
				<div class="faq_q" onclick="openFaq(this)">
				12. What kind of possible dangers one can confront while car transportation in India?
				<div class="arrowdown"></div>
				</div>
				<div class="faq_a">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt deserunt laborum eos harum a nobis laudantium saepe temporibus recusandae explicabo. Iste quis omnis quasi, deserunt cum in maiores assumenda recusandae quos minus illum consequuntur quidem incidunt exercitationem nam adipisci ex ipsam? Et, debitis inventore nesciunt quas sint veritatis deserunt earum.</div>
			</div>
			<div class="faq_card">
				<div class="faq_q" onclick="openFaq(this)">
				13. What preparations should be made before contacting car transportation service providers in India?
				<div class="arrowdown"></div>
				</div>
				<div class="faq_a">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt deserunt laborum eos harum a nobis laudantium saepe temporibus recusandae explicabo. Iste quis omnis quasi, deserunt cum in maiores assumenda recusandae quos minus illum consequuntur quidem incidunt exercitationem nam adipisci ex ipsam? Et, debitis inventore nesciunt quas sint veritatis deserunt earum.</div>
			</div>
			<div class="faq_card">
				<div class="faq_q" onclick="openFaq(this)">
				14. What kind of packing materials are used by car movers in India during shifting?
				<div class="arrowdown"></div>
				</div>
				<div class="faq_a">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt deserunt laborum eos harum a nobis laudantium saepe temporibus recusandae explicabo. Iste quis omnis quasi, deserunt cum in maiores assumenda recusandae quos minus illum consequuntur quidem incidunt exercitationem nam adipisci ex ipsam? Et, debitis inventore nesciunt quas sint veritatis deserunt earum.</div>
			</div>
			<div class="faq_card">
				<div class="faq_q" onclick="openFaq(this)">
				15. What is the safest way for car transport in India?
				<div class="arrowdown"></div>
				</div>
				<div class="faq_a">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt deserunt laborum eos harum a nobis laudantium saepe temporibus recusandae explicabo. Iste quis omnis quasi, deserunt cum in maiores assumenda recusandae quos minus illum consequuntur quidem incidunt exercitationem nam adipisci ex ipsam? Et, debitis inventore nesciunt quas sint veritatis deserunt earum.</div>
			</div>
			<div class="faq_card">
				<div class="faq_q" onclick="openFaq(this)">
				16. How to find top car shifting companies in India?
				<div class="arrowdown"></div>
				</div>
				<div class="faq_a">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt deserunt laborum eos harum a nobis laudantium saepe temporibus recusandae explicabo. Iste quis omnis quasi, deserunt cum in maiores assumenda recusandae quos minus illum consequuntur quidem incidunt exercitationem nam adipisci ex ipsam? Et, debitis inventore nesciunt quas sint veritatis deserunt earum.</div>
			</div>
			<div class="faq_card">
				<div class="faq_q" onclick="openFaq(this)">
				17. What are the factors for choosing reliable car shifting companies in India?
				<div class="arrowdown"></div>
				</div>
				<div class="faq_a">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt deserunt laborum eos harum a nobis laudantium saepe temporibus recusandae explicabo. Iste quis omnis quasi, deserunt cum in maiores assumenda recusandae quos minus illum consequuntur quidem incidunt exercitationem nam adipisci ex ipsam? Et, debitis inventore nesciunt quas sint veritatis deserunt earum.</div>
			</div>
			<div class="faq_card">
				<div class="faq_q" onclick="openFaq(this)">
				18. How to contact Anil Packers and Movers for connecting with the top car movers in my city?
				<div class="arrowdown"></div>
				</div>
				<div class="faq_a">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt deserunt laborum eos harum a nobis laudantium saepe temporibus recusandae explicabo. Iste quis omnis quasi, deserunt cum in maiores assumenda recusandae quos minus illum consequuntur quidem incidunt exercitationem nam adipisci ex ipsam? Et, debitis inventore nesciunt quas sint veritatis deserunt earum.</div>
			</div>
			<script>
				function openFaq(elem){
					const ans = elem.nextElementSibling;
					if(ans.style.height == ''){
						ans.style.height = ans.scrollHeight+40+'px';
						ans.classList.add('show');
					}else{
						ans.style.height = '';
						ans.classList.remove('show');
					}
				}
			</script>
		</section>
		<section class="py-4 px-0 px-md-3 px-lg-5 services">
			<h2 class="theme_text theme_underline text-center col-12 mb-5">Our Vehicle Shifting Services in India</h2>
				<div class="col-6 col-lg-4 px-3 mb-3" ><a href="<?php echo base_url('pages/location') ?>" class="service_location"> <img src="<?php echo base_url('image/location.png') ?>" alt="location icon" class="location_icon">Car Shifting Services in Pune</a></div>
				<div class="col-6 col-lg-4 px-3 mb-3" ><a href="<?php echo base_url('pages/location') ?>" class="service_location"> <img src="<?php echo base_url('image/location.png') ?>" alt="location icon" class="location_icon">Car Shifting Services in Mumbai</a></div>
				<div class="col-6 col-lg-4 px-3 mb-3" ><a href="<?php echo base_url('pages/location') ?>" class="service_location"> <img src="<?php echo base_url('image/location.png') ?>" alt="location icon" class="location_icon">Car Shifting Services in Ahmedabad</a></div>
				<div class="col-6 col-lg-4 px-3 mb-3" ><a href="<?php echo base_url('pages/location') ?>" class="service_location"> <img src="<?php echo base_url('image/location.png') ?>" alt="location icon" class="location_icon">Car Shifting Services in Bangalore</a></div>
				<div class="col-6 col-lg-4 px-3 mb-3" ><a href="<?php echo base_url('pages/location') ?>" class="service_location"> <img src="<?php echo base_url('image/location.png') ?>" alt="location icon" class="location_icon">Car Shifting Services in Delhi</a></div>
				<div class="col-6 col-lg-4 px-3 mb-3" ><a href="<?php echo base_url('pages/location') ?>" class="service_location"> <img src="<?php echo base_url('image/location.png') ?>" alt="location icon" class="location_icon">Car Shifting Services in Kolkata</a></div>
				<div class="col-6 col-lg-4 px-3 mb-3" ><a href="<?php echo base_url('pages/location') ?>" class="service_location"> <img src="<?php echo base_url('image/location.png') ?>" alt="location icon" class="location_icon">Car Shifting Services in Bhubaneswar</a></div>
				<div class="col-6 col-lg-4 px-3 mb-3" ><a href="<?php echo base_url('pages/location') ?>" class="service_location"> <img src="<?php echo base_url('image/location.png') ?>" alt="location icon" class="location_icon">Car Shifting Services in Chennai</a></div>
		</section>
	</main>
	<footer class="text-center theme_bg">all copyright reserved @2024</footer>
</body>

</html>